export const Base_Url = "http://agsdemo.in/insureapi/public/api";
export const Image_Url = "https://kmrlive.in/public/assets/images";
export const No_Image_Url =
  "https://kmrlive.in/public/assets/images/no_image.jpg";

export const Finacal_Year = "2024";
