const EmailContent = {
  subject: "Regarding Our Discussion",
  body: `Hi,\n\nPlease find the attached file below.\n\nBest Regards,`,
  attachmentUrl: "https://your-file-link.com/file.pdf",
};

export default EmailContent;
