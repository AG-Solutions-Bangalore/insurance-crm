import CryptoJS from "crypto-js";

const secretValidationKey = "f2a2d3f4a5b6c7d8e9f0123456789abc";
